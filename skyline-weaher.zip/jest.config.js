module.exports = {
  collectCoverage: true
};
