import { InjectionToken } from '@angular/core';

export const MAIN_PAGE_CITY_IDS = new InjectionToken<number[]>('MAIN_PAGE_CITY_IDS');
