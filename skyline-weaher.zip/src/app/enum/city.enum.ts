export enum City {
  Berlin = 2950159,
  Dublin = 2964574,
  Minsk = 625144,
  Prague = 3067696,
  Rome = 4908066,
}
