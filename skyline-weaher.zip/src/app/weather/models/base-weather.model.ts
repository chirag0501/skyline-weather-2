export interface BaseWeather {
  temp: number;
  feels_like: number;
  pressure: number;
  humidity: number;
}
