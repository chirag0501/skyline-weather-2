export interface GeoLocation {
  lon: number;
  lat: number;
}
