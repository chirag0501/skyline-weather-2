/*
 * Copyright 2019 BloomReach. All rights reserved. (https://www.bloomreach.com/)
 */

declare module '!!raw-loader!*' {
  const value: string;
  export default value;
}
