## Development server

Run `ng serve` for a local/dev server. 
local app URL : `http://localhost:4200/`.
Application will reload if you change any of the source files.

## Running unit tests

Run `ng test` to execute the unit tests 

## Build

Run `npm run build` to build application.
Artifacts will get stored in the `dist/` folder.
Ruu `npm run build:prod` to generate prouction build.
